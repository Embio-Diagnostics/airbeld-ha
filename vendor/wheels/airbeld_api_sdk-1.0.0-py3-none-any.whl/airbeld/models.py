"""Facade result types; wire models are generated in _generated.py."""

from pydantic import Field

from ._generated import LegacyDeviceId


class ResolvedDeviceId(LegacyDeviceId):
    """A resolver pair validated as complete before returning to callers.

    The archive omits required for the read-only fields; this response-only
    subclass requires both values rather than changing the generated contract.
    """

    id: int = Field(..., strict=True, ge=1)
    uid: str = Field(..., strict=True, min_length=1)
