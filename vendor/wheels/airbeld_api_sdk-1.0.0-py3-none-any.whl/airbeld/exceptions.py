"""Custom exceptions for the Airbeld API SDK."""


class AirbeldError(Exception):
    """Base exception for all Airbeld SDK errors."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


class AuthError(AirbeldError):
    """Authentication or authorization error (401/403)."""

    def __init__(self, message: str = "Authentication failed") -> None:
        super().__init__(message)


class RateLimitError(AirbeldError):
    """Rate limit exceeded error (429)."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: float | None = None,
    ) -> None:
        super().__init__(message)
        self.retry_after = retry_after


class ApiError(AirbeldError):
    """API error for other 4xx/5xx HTTP status codes."""

    def __init__(
        self,
        message: str,
        status_code: int,
        response_body: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class NetworkError(AirbeldError):
    """Network connectivity or timeout error."""

    def __init__(self, message: str = "Network error occurred") -> None:
        super().__init__(message)


class NotFoundError(ApiError):
    """Unknown or inaccessible resource (404)."""


class PaymentError(ApiError):
    """The caller's plan does not permit the operation (402)."""


class UpstreamError(ApiError):
    """Backend or upstream service failure (5xx)."""


class DeadlineError(NetworkError):
    """The overall operation budget expired."""


class ContractError(AirbeldError):
    """The backend returned a response outside the pinned contract."""
