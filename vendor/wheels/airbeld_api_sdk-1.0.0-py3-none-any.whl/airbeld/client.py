"""Bearer-token v2 facade, with bounded operations and injectable HTTP clients."""

import asyncio
import math
import time
from collections.abc import Sequence
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Any, Literal, TypeVar
from urllib.parse import quote

import httpx
from pydantic import BaseModel, TypeAdapter, ValidationError

from ._generated import (
    AlexaGrantInputRequest,
    BatchReadingsEntryV2,
    BatchReadingsResponseV2,
    BatchScoresEntryV2,
    BatchScoresResponseV2,
    DeviceStatusEntry,
    DeviceV2Detail,
    DeviceV2List,
    IntegrationLink,
    LegacyDeviceIdsResolveRequest,
    ReadingsBatchRequestRequest,
    ScoresBatchRequestRequest,
    UserPreferences,
)
from .exceptions import (
    ApiError,
    AuthError,
    ContractError,
    DeadlineError,
    NetworkError,
    NotFoundError,
    PaymentError,
    RateLimitError,
    UpstreamError,
)
from .models import ResolvedDeviceId
from .version import get_user_agent

Model = TypeVar("Model", bound=BaseModel)
Item = TypeVar("Item", str, int)


def _parse(model: type[Model], data: Any) -> Model:
    try:
        return model.model_validate(data)
    except ValidationError:
        # Suppress ValidationError's traceback context, which includes input values.
        raise ContractError(f"Invalid {model.__name__} response") from None


def _parse_list(model: type[Model], data: Any) -> list[Model]:
    if not isinstance(data, list):
        raise ContractError(f"Expected an array of {model.__name__}")
    return [_parse(model, item) for item in data]


def _chunks(items: Sequence[Item], cap: int) -> list[list[Item]]:
    unique = list(dict.fromkeys(items))
    return [unique[index : index + cap] for index in range(0, len(unique), cap)]


def _retry_after(value: str | None) -> float | None:
    if value is None:
        return None
    try:
        seconds = float(value)
    except ValueError:
        try:
            seconds = (parsedate_to_datetime(value) - datetime.now(timezone.utc)).total_seconds()
        except (ValueError, TypeError, OverflowError):
            return None
    return max(0.0, seconds) if math.isfinite(seconds) else None


def _handle_errors(response: httpx.Response) -> None:
    if response.is_success:
        return
    status = response.status_code
    # Do not put server-provided bodies (which may contain credentials) in messages.
    message = f"HTTP {status}"
    if status in (401, 403):
        raise AuthError(message)
    if status == 429:
        raise RateLimitError(message, retry_after=_retry_after(response.headers.get("Retry-After")))
    error_type = (
        NotFoundError
        if status == 404
        else PaymentError
        if status == 402
        else UpstreamError
        if status >= 500
        else ApiError
    )
    raise error_type(message, status, response.text)


class _Settings:
    def __init__(
        self,
        token: str,
        base_url: str,
        timeout: float | httpx.Timeout,
        deadline: float,
        concurrency: int,
        max_attempts: int,
    ) -> None:
        if deadline <= 0 or not math.isfinite(deadline):
            raise ValueError("deadline must be finite and positive")
        if concurrency < 1 or max_attempts < 1:
            raise ValueError("concurrency and max_attempts must be positive")
        self.base_url = base_url.rstrip("/") + "/api/v2/"
        self.timeout = httpx.Timeout(timeout)
        self.deadline = deadline
        self.concurrency = concurrency
        self.max_attempts = max_attempts
        self.headers = {"Authorization": f"Bearer {token}", "User-Agent": get_user_agent()}

    def set_token(self, new_token: str) -> None:
        """Replace the bearer token; token acquisition belongs to the caller."""
        self.headers["Authorization"] = f"Bearer {new_token}"

    def _remaining(self, expires: float) -> float:
        remaining = expires - time.monotonic()
        if remaining <= 0:
            raise DeadlineError("Operation deadline exceeded")
        return remaining

    def _timeout(self, remaining: float) -> httpx.Timeout:
        return httpx.Timeout(
            **{
                name: min(value, remaining) if value is not None else remaining
                for name, value in self.timeout.as_dict().items()
            }
        )

    def _delay(self, exc: NetworkError | RateLimitError, attempt: int) -> float:
        if isinstance(exc, RateLimitError) and exc.retry_after is not None:
            return exc.retry_after
        return min(0.1 * 2.0**attempt, 1.0)


class AirbeldClient(_Settings):
    """Async facade. Injected clients remain owned by the caller."""

    def __init__(
        self,
        token: str,
        base_url: str = "https://api.airbeld.com",
        timeout: float | httpx.Timeout = 10.0,
        *,
        client: httpx.AsyncClient | None = None,
        deadline: float = 10.0,
        concurrency: int = 4,
        max_attempts: int = 3,
    ) -> None:
        super().__init__(token, base_url, timeout, deadline, concurrency, max_attempts)
        self._owns_client = client is None
        self._client = client if client is not None else httpx.AsyncClient(headers=self.headers)

    async def __aenter__(self) -> "AirbeldClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        expires: float | None = None,
        retry_safe: bool = True,
        **kwargs: Any,
    ) -> httpx.Response:
        end = expires if expires is not None else time.monotonic() + self.deadline
        for attempt in range(self.max_attempts):
            try:
                remaining = self._remaining(end)
                response = await asyncio.wait_for(
                    self._client.request(
                        method,
                        self.base_url + path,
                        headers=self.headers,
                        timeout=self._timeout(remaining),
                        **kwargs,
                    ),
                    timeout=remaining,
                )
                _handle_errors(response)
                return response
            except asyncio.TimeoutError as exc:
                raise DeadlineError("Operation deadline exceeded") from exc
            except httpx.TransportError as exc:
                error: NetworkError | RateLimitError = NetworkError("HTTP transport failure")
                error.__cause__ = exc
            except RateLimitError as exc:
                error = exc
            if not retry_safe or attempt + 1 == self.max_attempts:
                raise error
            delay = self._delay(error, attempt)
            if delay >= self._remaining(end):
                raise error
            await asyncio.sleep(delay)
        raise AssertionError("unreachable")

    async def list_devices(self) -> list[DeviceV2List]:
        return _parse_list(DeviceV2List, (await self._request("GET", "devices/")).json())

    async def device(self, uid: str) -> DeviceV2Detail:
        uid = TypeAdapter(str).validate_python(uid, strict=True)
        return _parse(
            DeviceV2Detail, (await self._request("GET", f"devices/{quote(uid, safe='')}/")).json()
        )

    async def _batch(
        self,
        chunks: list[dict[str, Any]],
        path: str,
        response_model: type[Model],
    ) -> list[Model]:
        # A fixed worker set bounds both in-flight requests and scheduled tasks.
        end = time.monotonic() + self.deadline
        results: list[Model | None] = [None] * len(chunks)
        pending = iter(enumerate(chunks))

        async def worker() -> None:
            for index, payload in pending:
                response = await self._request("POST", path, expires=end, json=payload)
                results[index] = _parse(response_model, response.json())

        tasks = [asyncio.create_task(worker()) for _ in range(min(self.concurrency, len(chunks)))]
        try:
            await asyncio.wait_for(asyncio.gather(*tasks), timeout=self._remaining(end))
        except asyncio.TimeoutError as exc:
            raise DeadlineError("Operation deadline exceeded") from exc
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
        return [result for result in results if result is not None]

    async def latest_readings(self, uids: Sequence[str]) -> list[BatchReadingsEntryV2]:
        payloads = [
            ReadingsBatchRequestRequest.model_validate(
                {"deviceUids": chunk, "period": "latest"}
            ).model_dump(
                by_alias=True,
                exclude_none=True,
            )
            for chunk in _chunks(uids, 50)
        ]
        responses = await self._batch(payloads, "readings/batch/", BatchReadingsResponseV2)
        return [entry for response in responses for entry in response.results]

    async def scores(self, uids: Sequence[str]) -> list[BatchScoresEntryV2]:
        payloads = [
            ScoresBatchRequestRequest.model_validate({"uids": chunk}).model_dump(
                by_alias=True, exclude_none=True
            )
            for chunk in _chunks(uids, 50)
        ]
        responses = await self._batch(payloads, "scores/batch/", BatchScoresResponseV2)
        return [entry for response in responses for entry in response.results]

    async def device_status(self) -> list[DeviceStatusEntry]:
        return _parse_list(
            DeviceStatusEntry, (await self._request("GET", "devices/status/")).json()
        )

    async def preferences(self) -> UserPreferences:
        return _parse(UserPreferences, (await self._request("GET", "user-preferences/")).json())

    async def resolve_legacy_device_ids(self, ids: Sequence[int]) -> list[ResolvedDeviceId]:
        end = time.monotonic() + self.deadline
        resolved: dict[int, ResolvedDeviceId] = {}
        for chunk in _chunks(ids, 200):
            payload = LegacyDeviceIdsResolveRequest.model_validate({"ids": chunk}).model_dump()
            response = await self._request(
                "POST", "integrations/legacy-device-ids/resolve", expires=end, json=payload
            )
            for pair in _parse_list(ResolvedDeviceId, response.json()):
                resolved[pair.id] = pair
        return sorted(resolved.values(), key=lambda pair: pair.id)

    async def link_google(self) -> IntegrationLink:
        return _parse(
            IntegrationLink,
            (await self._request("POST", "integrations/google/link/", json={})).json(),
        )

    async def alexa_grant(
        self, grant_code: str, region: Literal["NA", "EU", "FE"]
    ) -> IntegrationLink:
        payload = AlexaGrantInputRequest.model_validate(
            {"grantCode": grant_code, "region": region}
        ).model_dump(by_alias=True)
        # An indeterminate grant exchange must not be retried by the SDK.
        return _parse(
            IntegrationLink,
            (
                await self._request(
                    "POST", "integrations/alexa/grant/", retry_safe=False, json=payload
                )
            ).json(),
        )

    async def unlink(self) -> None:
        """Disconnect the caller's Google link; v2 has no user Alexa unlink route."""
        await self._request("POST", "integrations/google/unlink/", json={})


class SyncAirbeldClient(_Settings):
    """Sync facade. Batches are sequential (one in-flight call) under one budget.

    httpx phase timeouts and the monotonic deadline cap requests and retry waits;
    unlike the async facade, sync transports cannot be forcibly cancelled.
    """

    def __init__(
        self,
        token: str,
        base_url: str = "https://api.airbeld.com",
        timeout: float | httpx.Timeout = 10.0,
        *,
        client: httpx.Client | None = None,
        deadline: float = 10.0,
        max_attempts: int = 3,
    ) -> None:
        super().__init__(token, base_url, timeout, deadline, 1, max_attempts)
        self._owns_client = client is None
        self._client = client if client is not None else httpx.Client(headers=self.headers)

    def __enter__(self) -> "SyncAirbeldClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def _request(
        self,
        method: str,
        path: str,
        *,
        expires: float | None = None,
        retry_safe: bool = True,
        **kwargs: Any,
    ) -> httpx.Response:
        end = expires if expires is not None else time.monotonic() + self.deadline
        for attempt in range(self.max_attempts):
            try:
                response = self._client.request(
                    method,
                    self.base_url + path,
                    headers=self.headers,
                    timeout=self._timeout(self._remaining(end)),
                    **kwargs,
                )
                self._remaining(end)
                _handle_errors(response)
                return response
            except httpx.TransportError as exc:
                error: NetworkError | RateLimitError = NetworkError("HTTP transport failure")
                error.__cause__ = exc
            except RateLimitError as exc:
                error = exc
            if not retry_safe or attempt + 1 == self.max_attempts:
                raise error
            delay = self._delay(error, attempt)
            if delay >= self._remaining(end):
                raise error
            time.sleep(delay)
        raise AssertionError("unreachable")

    def list_devices(self) -> list[DeviceV2List]:
        return _parse_list(DeviceV2List, self._request("GET", "devices/").json())

    def device(self, uid: str) -> DeviceV2Detail:
        uid = TypeAdapter(str).validate_python(uid, strict=True)
        return _parse(
            DeviceV2Detail, self._request("GET", f"devices/{quote(uid, safe='')}/").json()
        )

    def latest_readings(self, uids: Sequence[str]) -> list[BatchReadingsEntryV2]:
        end = time.monotonic() + self.deadline
        results: list[BatchReadingsEntryV2] = []
        for chunk in _chunks(uids, 50):
            payload = ReadingsBatchRequestRequest.model_validate(
                {"deviceUids": chunk, "period": "latest"}
            ).model_dump(by_alias=True, exclude_none=True)
            response = self._request("POST", "readings/batch/", expires=end, json=payload)
            results.extend(_parse(BatchReadingsResponseV2, response.json()).results)
        return results

    def scores(self, uids: Sequence[str]) -> list[BatchScoresEntryV2]:
        end = time.monotonic() + self.deadline
        results: list[BatchScoresEntryV2] = []
        for chunk in _chunks(uids, 50):
            payload = ScoresBatchRequestRequest.model_validate({"uids": chunk}).model_dump(
                by_alias=True, exclude_none=True
            )
            response = self._request("POST", "scores/batch/", expires=end, json=payload)
            results.extend(_parse(BatchScoresResponseV2, response.json()).results)
        return results

    def device_status(self) -> list[DeviceStatusEntry]:
        return _parse_list(DeviceStatusEntry, self._request("GET", "devices/status/").json())

    def preferences(self) -> UserPreferences:
        return _parse(UserPreferences, self._request("GET", "user-preferences/").json())

    def resolve_legacy_device_ids(self, ids: Sequence[int]) -> list[ResolvedDeviceId]:
        end = time.monotonic() + self.deadline
        resolved: dict[int, ResolvedDeviceId] = {}
        for chunk in _chunks(ids, 200):
            payload = LegacyDeviceIdsResolveRequest.model_validate({"ids": chunk}).model_dump()
            response = self._request(
                "POST", "integrations/legacy-device-ids/resolve", expires=end, json=payload
            )
            for pair in _parse_list(ResolvedDeviceId, response.json()):
                resolved[pair.id] = pair
        return sorted(resolved.values(), key=lambda pair: pair.id)

    def link_google(self) -> IntegrationLink:
        return _parse(
            IntegrationLink, self._request("POST", "integrations/google/link/", json={}).json()
        )

    def alexa_grant(self, grant_code: str, region: Literal["NA", "EU", "FE"]) -> IntegrationLink:
        payload = AlexaGrantInputRequest.model_validate(
            {"grantCode": grant_code, "region": region}
        ).model_dump(by_alias=True)
        return _parse(
            IntegrationLink,
            self._request(
                "POST", "integrations/alexa/grant/", retry_safe=False, json=payload
            ).json(),
        )

    def unlink(self) -> None:
        """Disconnect the caller's Google link; v2 has no user Alexa unlink route."""
        self._request("POST", "integrations/google/unlink/", json={})
