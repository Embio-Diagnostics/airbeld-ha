# Generated from the pinned v2 contract; do not edit.
from __future__ import annotations

from typing import Annotated, Any, Literal
from uuid import UUID

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, RootModel


class Model(RootModel[Any]):
    model_config = ConfigDict(populate_by_name=True)
    root: Any


class Eui64(RootModel[str]):
    model_config = ConfigDict(populate_by_name=True)
    root: Annotated[str, Field(max_length=16)]


class AccessProvenance(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    uuid: UUID
    target_kind: Annotated[
        Literal["device", "sector", "location", "organization"],
        Field(
            alias="targetKind",
            description="* `device` - device\n* `sector` - sector\n* `location` - location\n* `organization` - organization",
        ),
    ]
    target_name: Annotated[str, Field(alias="targetName")]
    remaining_role: Annotated[
        Literal["admin", "editor", "viewer"] | None, Field(alias="remainingRole")
    ]
    access_remains: Annotated[bool, Field(alias="accessRemains")]


class AccessOrganization(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    uuid: UUID
    name: str


class DisplayName(RootModel[str]):
    model_config = ConfigDict(populate_by_name=True)
    root: Annotated[
        str, Field(description="The name of the sensor as it should be displayed.", max_length=255)
    ]


class SensorV2(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: int | None = None
    name: Annotated[str, Field(description="The name of the sensor.", max_length=255)]
    display_name: Annotated[DisplayName | None, Field(alias="displayName")] = None
    description: str | None = None
    unit: Annotated[
        str | None,
        Field(description="The unit of measurement that the sensor uses.", max_length=255),
    ] = None
    description_el: Annotated[str | None, Field(alias="descriptionEl")] = None


class DeviceStatusEntry(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    uid: Annotated[str, Field(description="The device's unique identifier.")]
    status: Annotated[
        Literal["online", "offline"],
        Field(
            description="Server-computed liveness from the latest telemetry timestamp.\n\n* `online` - online\n* `offline` - offline"
        ),
    ]
    last_seen: Annotated[AwareDatetime | None, Field(alias="lastSeen")]
    stale: Annotated[
        bool,
        Field(description="True when the latest reading is older than the freshness threshold."),
    ]


class ReadingsCustomOrderItem(RootModel[str]):
    model_config = ConfigDict(populate_by_name=True)
    root: Annotated[str, Field(max_length=64)]


class UserPreferences(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    uuid: Annotated[
        UUID | None,
        Field(
            description="Opaque public identifier for this preferences record (ADR 0011). The column already existed and was simply never on the v2 wire; prefer it over the integer `id`."
        ),
    ] = None
    id: int | None = None
    home_productivity_device: Annotated[int | None, Field(alias="homeProductivityDevice")] = None
    work_productivity_device: Annotated[int | None, Field(alias="workProductivityDevice")] = None
    outdoor_productivity_city: Annotated[int | None, Field(alias="outdoorProductivityCity")] = None
    home_productivity_device_uid: Annotated[
        str | None, Field(alias="homeProductivityDeviceUid")
    ] = None
    work_productivity_device_uid: Annotated[
        str | None, Field(alias="workProductivityDeviceUid")
    ] = None
    readings_sort_mode: Annotated[
        Literal["worst_first", "worst_last", "alphabetical", "custom"] | None,
        Field(
            alias="readingsSortMode",
            description="How the Home readings tiles are ordered: `worst_first` (default), `worst_last`, `alphabetical`, or `custom` (follow `readingsCustomOrder`). Omit it on a PATCH to leave it unchanged.\n\n* `worst_first` - Worst first\n* `worst_last` - Worst last\n* `alphabetical` - Alphabetical\n* `custom` - Custom",
        ),
    ] = None
    readings_custom_order: Annotated[
        list[ReadingsCustomOrderItem] | None,
        Field(
            alias="readingsCustomOrder",
            description="Ordered set of sensor names (e.g. `co2`, `pm2p5`) for the `custom` sort mode, first tile first; defaults to an empty list. Names are non-blank strings without repeats; a name the server's sensor catalogue does not list is accepted. Omit it on a PATCH to leave it unchanged.",
            max_length=64,
        ),
    ] = None
    unit_system: Annotated[Literal["metric", "imperial_us"] | None, Field(alias="unitSystem")] = (
        None
    )


class ReadingValue(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    timestamp: Annotated[
        AwareDatetime,
        Field(
            description="The bucket's timestamp (ISO-8601), rendered in the device's location timezone — the same tz reported by the payload's `timezone` field."
        ),
    ]
    value: float | None


class SeriesAggregates(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    avg: float | None
    max: float | None


class LatestIaqScore(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    score: Annotated[
        float, Field(description="Latest computed score. Zero is a valid score, not missing data.")
    ]
    measured_at: Annotated[
        AwareDatetime,
        Field(
            alias="measuredAt",
            description="Telemetry timestamp from which this score was computed.",
        ),
    ]
    freshness: Annotated[
        Literal["fresh", "stale"],
        Field(
            description="Derived at response time from measuredAt and the device threshold.\n\n* `fresh` - fresh\n* `stale` - stale"
        ),
    ]
    band: Annotated[
        Literal["excellent", "good", "moderate", "unhealthy", "hazardous"],
        Field(
            description="Air-quality band decided once by the server so every client names the air the same way. The score is rounded half-up to an integer, then: 80 or more is 'excellent', 60 to 79 'good', 40 to 59 'moderate', 20 to 39 'unhealthy', and below 20 'hazardous'. The comfort axis carries no band.\n\n* `excellent` - excellent\n* `good` - good\n* `moderate` - moderate\n* `unhealthy` - unhealthy\n* `hazardous` - hazardous"
        ),
    ]


class LatestScore(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    score: Annotated[
        float, Field(description="Latest computed score. Zero is a valid score, not missing data.")
    ]
    measured_at: Annotated[
        AwareDatetime,
        Field(
            alias="measuredAt",
            description="Telemetry timestamp from which this score was computed.",
        ),
    ]
    freshness: Annotated[
        Literal["fresh", "stale"],
        Field(
            description="Derived at response time from measuredAt and the device threshold.\n\n* `fresh` - fresh\n* `stale` - stale"
        ),
    ]


class LegacyDeviceId(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: int | None = None
    uid: str | None = None


class Id(RootModel[int]):
    model_config = ConfigDict(populate_by_name=True)
    root: Annotated[int, Field(ge=1, le=9223372036854775807)]


class LegacyDeviceIdsResolveRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    ids: Annotated[list[Id], Field(max_length=200)]


class DeviceUid(RootModel[str]):
    model_config = ConfigDict(populate_by_name=True)
    root: Annotated[str, Field(max_length=255, min_length=1)]


class Start(RootModel[str]):
    model_config = ConfigDict(populate_by_name=True)
    root: Annotated[
        str,
        Field(description="Window start, UTC ISO-8601 (e.g. 2026-06-20T00:00:00Z).", min_length=1),
    ]


class End(RootModel[str]):
    model_config = ConfigDict(populate_by_name=True)
    root: Annotated[str, Field(description="Window end (exclusive), UTC ISO-8601.", min_length=1)]


class Sensor(RootModel[str]):
    model_config = ConfigDict(populate_by_name=True)
    root: Annotated[
        str,
        Field(
            description="Restrict the response to one sensor by name (all sensors if omitted).",
            min_length=1,
        ),
    ]


class ReadingsBatchRequestRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    device_uids: Annotated[
        list[DeviceUid],
        Field(
            alias="deviceUids",
            description="The device uids to fetch (1..50). Over the cap is a 400. An inaccessible/unknown uid is reported uniformly as 'forbidden' in the response (never an existence oracle).",
            max_length=50,
        ),
    ]
    start: Start | None = None
    end: End | None = None
    period: Annotated[
        Literal["latest", "hour", "day"],
        Field(
            description="The aggregation period applied to every device's series.\n\n* `latest` - latest\n* `hour` - hour\n* `day` - day"
        ),
    ] = "latest"
    sensor: Sensor | None = None


class Uid(RootModel[str]):
    model_config = ConfigDict(populate_by_name=True)
    root: Annotated[str, Field(max_length=255, min_length=1)]


class ScoresBatchRequestRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    uids: Annotated[
        list[Uid] | None,
        Field(
            description="Device uids to fetch (at most 50 unique and 200 raw entries). Duplicates are removed while preserving order. An explicit empty array returns zero results; omit the field to fetch all owned devices.",
            max_length=200,
        ),
    ] = None


class AlexaGrantInputRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    grant_code: Annotated[str, Field(alias="grantCode", max_length=4096, min_length=1)]
    region: Annotated[
        Literal["NA", "EU", "FE"],
        Field(description="* `NA` - North America\n* `EU` - Europe\n* `FE` - Far East"),
    ]


class IntegrationLink(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    uuid: UUID | None = None
    provider: Annotated[
        Literal["google", "alexa"] | None,
        Field(description="* `google` - Google Home\n* `alexa` - Alexa"),
    ] = None
    region: Annotated[
        Literal["", "NA", "EU", "FE"] | None,
        Field(
            description="* `` - Not applicable (Google)\n* `NA` - North America\n* `EU` - Europe\n* `FE` - Far East"
        ),
    ] = None
    generation: int | None = None
    status: Annotated[
        Literal["pending", "active", "revoked"] | None,
        Field(description="* `pending` - Pending\n* `active` - Active\n* `revoked` - Revoked"),
    ] = None
    created_at: Annotated[AwareDatetime | None, Field(alias="createdAt")] = None
    updated_at: Annotated[AwareDatetime | None, Field(alias="updatedAt")] = None
    revoked_at: Annotated[AwareDatetime | None, Field(alias="revokedAt")] = None


class DeviceV2List(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    uid: Annotated[
        str,
        Field(
            description="A unique identifier for the device.", max_length=255, title="Device UID"
        ),
    ]
    name: Annotated[
        str,
        Field(
            description="The device's HARDWARE IDENTITY: the name its SoftAP setup network carries, and the value every claim route resolves a device by. POLICY, not a model-level guarantee: it is set at registration and must not be changed afterwards, because renaming it denies the real owner their claim path. It is enforced at three edges only: the v2 update routes ignore it, the admin change form does not offer it, and the admin CSV import applies it on create. It stays writable through PATCH/PUT /api/v1/devices/{pk}/ and through any direct save() (shell, support script, data migration), and the column has no uniqueness constraint. The customer-facing label is display_name.",
            max_length=255,
            title="Device Name",
        ),
    ]
    display_name: Annotated[
        str,
        Field(
            alias="displayName",
            description="The name of the device as it should be displayed.",
            max_length=255,
        ),
    ]
    description: Annotated[
        str | None,
        Field(description="A detailed description of the device.", title="Device Description"),
    ] = None
    type: str | None = None
    status: Annotated[
        str | None,
        Field(description="``online`` / ``offline`` from the latest reading vs the threshold."),
    ] = None
    sector: str | None = None
    sector_uuid: Annotated[UUID | None, Field(alias="sectorUuid")] = None
    location: Annotated[
        str | None, Field(description="Get the location name from the device's sector")
    ] = None
    location_uuid: Annotated[UUID | None, Field(alias="locationUuid")] = None
    timezone: Annotated[
        str | None, Field(description="Get the timezone from the device's location")
    ] = None
    effective_role: Annotated[str | None, Field(alias="effectiveRole")] = None
    ownership: Annotated[
        Literal["owned", "shared", "organization", "inventory"] | None,
        Field(
            description="* `owned` - owned\n* `shared` - shared\n* `organization` - organization\n* `inventory` - inventory"
        ),
    ] = None
    owner_email: Annotated[str | None, Field(alias="ownerEmail")] = None
    shared_by: Annotated[str | None, Field(alias="sharedBy")] = None
    access_provenance: Annotated[AccessProvenance | None, Field(alias="accessProvenance")] = None
    owning_organization: Annotated[AccessOrganization | None, Field(alias="owningOrganization")] = (
        None
    )
    eui64: Eui64 | None = None
    legacy_id: Annotated[int | None, Field(alias="legacyId")] = None
    last_seen: Annotated[AwareDatetime | None, Field(alias="lastSeen")] = None
    stale: Annotated[
        bool | None,
        Field(description="True when the latest reading is older than the freshness threshold."),
    ] = None


class DeviceV2Detail(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    uid: Annotated[
        str,
        Field(
            description="A unique identifier for the device.", max_length=255, title="Device UID"
        ),
    ]
    name: Annotated[
        str,
        Field(
            description="The device's HARDWARE IDENTITY: the name its SoftAP setup network carries, and the value every claim route resolves a device by. POLICY, not a model-level guarantee: it is set at registration and must not be changed afterwards, because renaming it denies the real owner their claim path. It is enforced at three edges only: the v2 update routes ignore it, the admin change form does not offer it, and the admin CSV import applies it on create. It stays writable through PATCH/PUT /api/v1/devices/{pk}/ and through any direct save() (shell, support script, data migration), and the column has no uniqueness constraint. The customer-facing label is display_name.",
            max_length=255,
            title="Device Name",
        ),
    ]
    display_name: Annotated[
        str,
        Field(
            alias="displayName",
            description="The name of the device as it should be displayed.",
            max_length=255,
        ),
    ]
    description: Annotated[
        str | None,
        Field(description="A detailed description of the device.", title="Device Description"),
    ] = None
    type: str | None = None
    status: Annotated[
        str | None,
        Field(description="``online`` / ``offline`` from the latest reading vs the threshold."),
    ] = None
    sector: str | None = None
    sector_uuid: Annotated[UUID | None, Field(alias="sectorUuid")] = None
    location: Annotated[
        str | None, Field(description="Get the location name from the device's sector")
    ] = None
    location_uuid: Annotated[UUID | None, Field(alias="locationUuid")] = None
    timezone: Annotated[
        str | None, Field(description="Get the timezone from the device's location")
    ] = None
    sensors: list[SensorV2] | None = None
    effective_role: Annotated[str | None, Field(alias="effectiveRole")] = None
    ownership: Annotated[
        Literal["owned", "shared", "organization", "inventory"] | None,
        Field(
            description="* `owned` - owned\n* `shared` - shared\n* `organization` - organization\n* `inventory` - inventory"
        ),
    ] = None
    owner_email: Annotated[str | None, Field(alias="ownerEmail")] = None
    shared_by: Annotated[str | None, Field(alias="sharedBy")] = None
    access_provenance: Annotated[AccessProvenance | None, Field(alias="accessProvenance")] = None
    owning_organization: Annotated[AccessOrganization | None, Field(alias="owningOrganization")] = (
        None
    )
    eui64: Eui64 | None = None
    legacy_id: Annotated[int | None, Field(alias="legacyId")] = None
    last_seen: Annotated[AwareDatetime | None, Field(alias="lastSeen")] = None
    stale: Annotated[
        bool | None,
        Field(description="True when the latest reading is older than the freshness threshold."),
    ] = None


class ReadingsSensorSeries(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    name: Annotated[str, Field(description="The sensor's machine name.")]
    display_name: Annotated[str | None, Field(alias="displayName")]
    unit: Annotated[str, Field(description="The sensor's unit (empty for an index/score).")]
    description: str | None = None
    values: Annotated[
        list[ReadingValue], Field(description="The bucketed reading series for this sensor.")
    ]
    aggregates: Annotated[
        SeriesAggregates,
        Field(description="Pre-computed avg/max over the series (so clients skip the math)."),
    ]
    description_el: Annotated[str | None, Field(alias="descriptionEl")]


class BatchScoresEntryV2(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    uid: Annotated[str, Field(description="The requested device uid (echoed back).")]
    status: Annotated[
        Literal["ok", "forbidden"],
        Field(
            description="'ok' = accessible; 'forbidden' = inaccessible or unknown, reported uniformly to prevent enumeration.\n\n* `ok` - ok\n* `forbidden` - forbidden"
        ),
    ]
    iaq: LatestIaqScore | None
    comfort: LatestScore | None


class BatchReadingsEntryV2(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    uid: Annotated[str, Field(description="The requested device uid (echoed back).")]
    status: Annotated[
        Literal["ok", "forbidden", "sensor_unavailable"],
        Field(
            description="'ok' = accessible (sensors present); 'forbidden' = inaccessible OR unknown (reported uniformly — never an existence oracle); 'sensor_unavailable' = accessible, but the request's `sensor` is not one of this device's database columns (only with a `sensor` filter; `sensors` is empty and nothing was read for it).\n\n* `ok` - ok\n* `forbidden` - forbidden\n* `sensor_unavailable` - sensor_unavailable"
        ),
    ]
    sensors: Annotated[
        dict[str, ReadingsSensorSeries] | None,
        Field(
            description="Per-sensor series keyed by sensor name (on an 'ok' entry; always empty on a 'sensor_unavailable' one; absent on a 'forbidden' one)."
        ),
    ] = None
    data_starts_at: Annotated[AwareDatetime | None, Field(alias="dataStartsAt")] = None


class BatchScoresResponseV2(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    as_of: Annotated[
        AwareDatetime,
        Field(
            alias="asOf",
            description="UTC instant used to derive every freshness value in this response.",
        ),
    ]
    results: Annotated[
        list[BatchScoresEntryV2],
        Field(description="One result per deduplicated uid, in request order."),
    ]


class BatchReadingsResponseV2(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    period: Annotated[
        Literal["latest", "hour", "day"],
        Field(description="* `latest` - latest\n* `hour` - hour\n* `day` - day"),
    ]
    start: AwareDatetime | None
    end: AwareDatetime | None
    truncated_to: Annotated[int | None, Field(alias="truncatedTo")]
    results: Annotated[
        list[BatchReadingsEntryV2],
        Field(description="One entry per requested uid (order preserved)."),
    ]
