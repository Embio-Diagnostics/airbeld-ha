"""Version information for airbeld-api-sdk.

This file is the single version source: hatch reads ``__version__`` below to set the
package metadata (see ``[tool.hatch.version]`` in pyproject.toml).
"""

__version__ = "1.0.0"


def get_user_agent() -> str:
    """Get the User-Agent string for SDK requests."""
    return f"airbeld-api-sdk/{__version__}"
